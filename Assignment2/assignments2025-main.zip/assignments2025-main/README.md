# Assignments2025



## Getting started

Download / clone the directory. Read the instructions in the PDF. Follow the instructions. Contact Elin or a TA if you encounter problems.